"""
Purpose: Pydantic schemas for Feedback and scoring evaluation metrics.
Defines FeedbackResponse, CriteriaScore, and EvaluationSummary schemas.
"""
