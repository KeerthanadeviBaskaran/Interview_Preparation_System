"""
Purpose: SQLAlchemy model definition for Feedback entity.
Defines schema for automated interview evaluations, scoring metrics, strengths, weaknesses, and overall rating.
"""
