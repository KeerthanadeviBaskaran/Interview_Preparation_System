"""
Purpose: Core package initialization.
"""
