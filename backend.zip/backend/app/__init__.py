"""
Purpose: App package initialization.
"""
