"""
Purpose: Database package initialization.
"""
