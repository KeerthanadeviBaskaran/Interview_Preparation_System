from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.session import get_db
from app.schemas.interview import QuestionGenerateRequest, InterviewSessionResponse
from app.services.interview_service import InterviewService
from app.api.deps import get_current_active_user
from app.models.user import User

router = APIRouter(prefix="/interview", tags=["AI Interview Generator"])


@router.post("/questions/generate", response_model=InterviewSessionResponse, status_code=status.HTTP_201_CREATED)
def generate_interview_questions(
    req: QuestionGenerateRequest = QuestionGenerateRequest(),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Dynamically generates personalized AI interview questions using Candidate Profile,
    Resume Analysis, Skill Gap Analysis, and Selected Target Role context.

    Includes question categories:
    - Technical
    - Coding
    - Behavioral
    - Scenario-Based
    - HR

    Each question includes:
    - question text
    - category & difficulty (Easy, Medium, Hard)
    - expected_topics
    - ideal_answer_points
    - evaluation_criteria
    - estimated_time_minutes

    Stores the generated interview session in SQLite database.
    """
    return InterviewService.generate_questions_for_user(db=db, user_id=current_user.id, req=req)


@router.get("/questions", response_model=InterviewSessionResponse)
def get_interview_questions(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """
    Retrieve existing stored interview session and questions for the authenticated user.
    """
    session = InterviewService.get_user_latest_interview(db=db, user_id=current_user.id)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No interview session found. Please generate questions first using POST /api/v1/interview/questions/generate."
        )
    return session
